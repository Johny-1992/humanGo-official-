# 🤖 HumanGo (HGO) Telegram Bot

Un bot Telegram qui distribue automatiquement des HGO via TON à chaque utilisateur.

## 🔧 Installation sous Termux

```bash
pkg update && pkg upgrade
pkg install python git
pip install -r requirements.txt
python bot.py
```

## 📡 Hébergement sur GitHub + Ultime Robot

1. Créez un dépôt
2. Poussez tous les fichiers de ce dossier
3. Connectez GitHub à Ultime Robot (plan gratuit)
4. Le bot sera actif 24h/24 avec API Toncenter