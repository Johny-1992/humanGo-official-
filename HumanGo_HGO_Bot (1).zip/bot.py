import telebot
import os
from send_hgo import send_hgo
from dotenv import load_dotenv
import sqlite3

load_dotenv()
TOKEN = os.getenv("BOT_TOKEN")
bot = telebot.TeleBot(TOKEN)

db = sqlite3.connect("database.db", check_same_thread=False)
cursor = db.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (user_id INTEGER, ton_address TEXT, invited_by INTEGER, UNIQUE(ton_address))")
db.commit()

@bot.message_handler(commands=["start"])
def welcome(message):
    lang = message.from_user.language_code or "en"
    ref_id = message.text.split(" ")[1] if len(message.text.split()) > 1 else None
    text = {
        "fr": "Bienvenue chez HumanGo (HGO) 🔥 le token de humanisme et de l'égalité où personne n'est une baleine. Donnes ton adresse TON et reçois 10 HGO gratuitement. Invite tes amis avec ton lien et reçois 5 HGO par parrainage.",
        "en": "Welcome to HumanGo (HGO) 🔥 the token of humanism and equality where no one is a whale. Send your TON address to receive 10 HGO for free. Invite friends with your link and get 5 HGO per referral."
    }.get(lang, "Welcome to HumanGo (HGO)! Send your TON address to receive tokens.")
    bot.reply_to(message, text)

@bot.message_handler(func=lambda m: m.text and m.text.startswith("UQ"))
def handle_ton_address(message):
    user_id = message.from_user.id
    ton_address = message.text.strip()
    invited_by = None
    if len(message.text.split()) > 1:
        invited_by = int(message.text.split()[1])
    try:
        cursor.execute("INSERT INTO users (user_id, ton_address, invited_by) VALUES (?, ?, ?)", (user_id, ton_address, invited_by))
        db.commit()
        bot.reply_to(message, "⏳ Distribution en cours...")
        send_hgo(ton_address, 10)
        if invited_by:
            cursor.execute("SELECT ton_address FROM users WHERE user_id=?", (invited_by,))
            ref_row = cursor.fetchone()
            if ref_row:
                send_hgo(ref_row[0], 5)
    except sqlite3.IntegrityError:
        bot.reply_to(message, "❌ Cette adresse a déjà reçu des HGO.")

bot.polling()