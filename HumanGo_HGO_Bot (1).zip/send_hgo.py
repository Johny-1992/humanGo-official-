import requests
import os
from dotenv import load_dotenv

load_dotenv()
TON_API = os.getenv("TON_API_KEY")
FROM_ADDRESS = os.getenv("FROM_ADDRESS")
SMART_CONTRACT = os.getenv("SMART_CONTRACT")

def send_hgo(to_address, amount):
    try:
        tx_data = {
            "from_address": FROM_ADDRESS,
            "to_address": to_address,
            "amount": amount * (10 ** 9),  # assuming 9 decimals
            "contract_address": SMART_CONTRACT,
            "api_key": TON_API
        }
        response = requests.post("https://toncenter.com/api/v2/sendTransaction", json=tx_data)
        if response.status_code == 200:
            print(f"✅ Envoyé {amount} HGO à {to_address}")
        else:
            print(f"❌ Échec: {response.text}")
    except Exception as e:
        print(f"Erreur: {e}")